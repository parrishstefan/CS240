#!/bin/bash

#Program: Assignment 4: King of Assembly
#Author: Stefan Parrish

#Delete some un-needed files
rm *.o
rm *.out

echo "Assemble control.asm"
nasm -f elf64 -l control.lis -o control.o control.asm

echo "Assemble fill.asm"
nasm -f elf64 -l fill.lis -o fill.o fill.asm

echo "Assemble harmonic.asm"
nasm -f elf64 -l harmonic.lis -o harmonic.o harmonic.asm

echo "Compile isfloat.cpp using the gcc compiler standard 2011"
g++ -c -m64 -Wall -l isfloat.lis -o isfloat.o isfloat.cpp -fno-pie -no-pie

echo "Compile main.cpp using the g++ compiler"
g++ -c -m64 -Wall -std=c++17 -fno-pie -no-pie -o main.o main.cpp

echo "Compile display.cpp using the gcc compiler standard 2011"
g++ -c -m64 -Wall -l display.lis -o display.o display.cpp -fno-pie -no-pie

echo "Link the object files using the g++ linker standard 2011"
g++ -m64 -no-pie -o final.out main.o control.o fill.o isfloat.o display.o harmonic.o -std=c11

echo "Run the program Assignment 4: King of Assembly"
./final.out

echo "The script file will terminate"





